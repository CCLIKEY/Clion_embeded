/*
 * MIT License
 * Copyright (c) 2019 _VIFEXTech
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
#include "gpio.h"

const PinInfo_TypeDef PIN_MAP[PIN_MAX] =
{
    /*GPIO_TypeDef* GPIOx;  //对应GPIOx地址
    TIM_TypeDef* TIMx;      //对应TIMx地址
    ADC_TypeDef* ADCx;      //对应ADCx地址

    uint16_t GPIO_PIN_x;    //对应GPIO_Pin位
    uint8_t TimerChannel;   //对应定时器通道
    uint8_t ADC_Channel;*/  //对应ADC通道 

    {GPIOA, TIM2, ADC1,  GPIO_PIN_0, 1, ADC_CHANNEL_0}, /* PA0 */
    {GPIOA, TIM2, ADC1,  GPIO_PIN_1, 2, ADC_CHANNEL_1}, /* PA1 */
    {GPIOA, TIM2, ADC1,  GPIO_PIN_2, 3, ADC_CHANNEL_2}, /* PA2 */
    {GPIOA, TIM2, ADC1,  GPIO_PIN_3, 4, ADC_CHANNEL_3}, /* PA3 */
    {GPIOA, NULL, ADC1,  GPIO_PIN_4, 0, ADC_CHANNEL_4}, /* PA4 */
    {GPIOA, NULL, ADC1,  GPIO_PIN_5, 0, ADC_CHANNEL_5}, /* PA5 */
    {GPIOA, TIM3, ADC1,  GPIO_PIN_6, 1, ADC_CHANNEL_6}, /* PA6 */
    {GPIOA, TIM3, ADC1,  GPIO_PIN_7, 2, ADC_CHANNEL_7}, /* PA7 */
    {GPIOA, TIM1, NULL,  GPIO_PIN_8, 1, ADC_CHANNEL_NULL}, /* PA8 */
    {GPIOA, TIM1, NULL,  GPIO_PIN_9, 2, ADC_CHANNEL_NULL}, /* PA9 */
    {GPIOA, TIM1, NULL, GPIO_PIN_10, 3, ADC_CHANNEL_NULL}, /* PA10 */
    {GPIOA, TIM1, NULL, GPIO_PIN_11, 4, ADC_CHANNEL_NULL}, /* PA11 */
    {GPIOA, NULL, NULL, GPIO_PIN_12, 0, ADC_CHANNEL_NULL}, /* PA12 */
    {GPIOA, NULL, NULL, GPIO_PIN_13, 0, ADC_CHANNEL_NULL}, /* PA13 */
    {GPIOA, NULL, NULL, GPIO_PIN_14, 0, ADC_CHANNEL_NULL}, /* PA14 */
    {GPIOA, TIM2, NULL, GPIO_PIN_15, 1, ADC_CHANNEL_NULL}, /* PA15 */

    {GPIOB, TIM3, ADC1,  GPIO_PIN_0, 3, ADC_CHANNEL_8}, /* PB0 */
    {GPIOB, TIM3, ADC1,  GPIO_PIN_1, 4, ADC_CHANNEL_9}, /* PB1 */
    {GPIOB, NULL, NULL,  GPIO_PIN_2, 0, ADC_CHANNEL_NULL}, /* PB2 */
    {GPIOB, TIM2, NULL,  GPIO_PIN_3, 2, ADC_CHANNEL_NULL}, /* PB3 */
    {GPIOB, TIM3, NULL,  GPIO_PIN_4, 1, ADC_CHANNEL_NULL}, /* PB4 */
    {GPIOB, TIM3, NULL,  GPIO_PIN_5, 2, ADC_CHANNEL_NULL}, /* PB5 */
    {GPIOB, TIM4, NULL,  GPIO_PIN_6, 1, ADC_CHANNEL_NULL}, /* PB6 */
    {GPIOB, TIM4, NULL,  GPIO_PIN_7, 2, ADC_CHANNEL_NULL}, /* PB7 */
    {GPIOB, TIM4, NULL,  GPIO_PIN_8, 3, ADC_CHANNEL_NULL}, /* PB8 */
    {GPIOB, TIM4, NULL,  GPIO_PIN_9, 4, ADC_CHANNEL_NULL}, /* PB9 */
    {GPIOB, TIM2, NULL, GPIO_PIN_10, 3, ADC_CHANNEL_NULL}, /* PB10 */
    {GPIOB, TIM2, NULL, GPIO_PIN_11, 4, ADC_CHANNEL_NULL}, /* PB11 */
    {GPIOB, NULL, NULL, GPIO_PIN_12, 0, ADC_CHANNEL_NULL}, /* PB12 */
    {GPIOB, NULL, NULL, GPIO_PIN_13, 0, ADC_CHANNEL_NULL}, /* PB13 */
    {GPIOB, TIM12, NULL, GPIO_PIN_14, 1, ADC_CHANNEL_NULL},/* PB14 */
    {GPIOB, NULL, NULL, GPIO_PIN_15, 0, ADC_CHANNEL_NULL}, /* PB15 */

    {GPIOC, NULL, ADC1,  GPIO_PIN_0, 0, ADC_CHANNEL_10},/* PC0 */
    {GPIOC, NULL, ADC1,  GPIO_PIN_1, 0, ADC_CHANNEL_11},/* PC1 */
    {GPIOC, NULL, ADC1,  GPIO_PIN_2, 0, ADC_CHANNEL_12},/* PC2 */
    {GPIOC, NULL, ADC1,  GPIO_PIN_3, 0, ADC_CHANNEL_13},/* PC3 */
    {GPIOC, NULL, ADC1,  GPIO_PIN_4, 0, ADC_CHANNEL_14},/* PC4 */
    {GPIOC, NULL, ADC1,  GPIO_PIN_5, 0, ADC_CHANNEL_15},/* PC5 */
    {GPIOC, TIM3, NULL,  GPIO_PIN_6, 1, ADC_CHANNEL_NULL}, /* PC6 */
    {GPIOC, TIM3, NULL,  GPIO_PIN_7, 2, ADC_CHANNEL_NULL}, /* PC7 */
    {GPIOC, TIM3, NULL,  GPIO_PIN_8, 3, ADC_CHANNEL_NULL}, /* PC8 */
    {GPIOC, TIM3, NULL,  GPIO_PIN_9, 4, ADC_CHANNEL_NULL}, /* PC9 */
    {GPIOC, NULL, NULL, GPIO_PIN_10, 0, ADC_CHANNEL_NULL}, /* PC10 */
    {GPIOC, NULL, NULL, GPIO_PIN_11, 0, ADC_CHANNEL_NULL}, /* PC11 */
    {GPIOC, NULL, NULL, GPIO_PIN_12, 0, ADC_CHANNEL_NULL}, /* PC12 */
    {GPIOC, NULL, NULL, GPIO_PIN_13, 0, ADC_CHANNEL_NULL}, /* PC13 */
    {GPIOC, NULL, NULL, GPIO_PIN_14, 0, ADC_CHANNEL_NULL}, /* PC14 */
    {GPIOC, NULL, NULL, GPIO_PIN_15, 0, ADC_CHANNEL_NULL}, /* PC15 */

    {GPIOD, NULL, NULL,  GPIO_PIN_0, 0, ADC_CHANNEL_NULL}, /* PD0 */
    {GPIOD, NULL, NULL,  GPIO_PIN_1, 0, ADC_CHANNEL_NULL}, /* PD1 */
    {GPIOD, NULL, NULL,  GPIO_PIN_2, 0, ADC_CHANNEL_NULL}, /* PD2 */
    {GPIOD, NULL, NULL,  GPIO_PIN_3, 0, ADC_CHANNEL_NULL}, /* PD3 */
    {GPIOD, NULL, NULL,  GPIO_PIN_4, 0, ADC_CHANNEL_NULL}, /* PD4 */
    {GPIOD, NULL, NULL,  GPIO_PIN_5, 0, ADC_CHANNEL_NULL}, /* PD5 */
    {GPIOD, NULL, NULL,  GPIO_PIN_6, 0, ADC_CHANNEL_NULL}, /* PD6 */
    {GPIOD, NULL, NULL,  GPIO_PIN_7, 0, ADC_CHANNEL_NULL}, /* PD7 */
    {GPIOD, NULL, NULL,  GPIO_PIN_8, 0, ADC_CHANNEL_NULL}, /* PD8 */
    {GPIOD, NULL, NULL,  GPIO_PIN_9, 0, ADC_CHANNEL_NULL}, /* PD9 */
    {GPIOD, NULL, NULL, GPIO_PIN_10, 0, ADC_CHANNEL_NULL}, /* PD10 */
    {GPIOD, NULL, NULL, GPIO_PIN_11, 0, ADC_CHANNEL_NULL}, /* PD11 */
    {GPIOD, TIM4, NULL, GPIO_PIN_12, 1, ADC_CHANNEL_NULL}, /* PD12 */
    {GPIOD, TIM4, NULL, GPIO_PIN_13, 2, ADC_CHANNEL_NULL}, /* PD13 */
    {GPIOD, TIM4, NULL, GPIO_PIN_14, 3, ADC_CHANNEL_NULL}, /* PD14 */
    {GPIOD, TIM4, NULL, GPIO_PIN_15, 4, ADC_CHANNEL_NULL}, /* PD15 */

    {GPIOE, NULL, NULL,  GPIO_PIN_0, 0, ADC_CHANNEL_NULL}, /* PE0 */
    {GPIOE, NULL, NULL,  GPIO_PIN_1, 0, ADC_CHANNEL_NULL}, /* PE1 */
    {GPIOE, NULL, NULL,  GPIO_PIN_2, 0, ADC_CHANNEL_NULL}, /* PE2 */
    {GPIOE, NULL, NULL,  GPIO_PIN_3, 0, ADC_CHANNEL_NULL}, /* PE3 */
    {GPIOE, NULL, NULL,  GPIO_PIN_4, 0, ADC_CHANNEL_NULL}, /* PE4 */
    {GPIOE, NULL, NULL,  GPIO_PIN_5, 1, ADC_CHANNEL_NULL}, /* PE5 */
    {GPIOE, NULL, NULL,  GPIO_PIN_6, 2, ADC_CHANNEL_NULL}, /* PE6 */
    {GPIOE, NULL, NULL,  GPIO_PIN_7, 0, ADC_CHANNEL_NULL}, /* PE7 */
    {GPIOE, NULL, NULL,  GPIO_PIN_8, 0, ADC_CHANNEL_NULL}, /* PE8 */
    {GPIOE, TIM1, NULL,  GPIO_PIN_9, 1, ADC_CHANNEL_NULL}, /* PE9 */
    {GPIOE, NULL, NULL, GPIO_PIN_10, 0, ADC_CHANNEL_NULL}, /* PE10 */
    {GPIOE, TIM1, NULL, GPIO_PIN_11, 2, ADC_CHANNEL_NULL}, /* PE11 */
    {GPIOE, NULL, NULL, GPIO_PIN_12, 0, ADC_CHANNEL_NULL}, /* PE12 */
    {GPIOE, TIM1, NULL, GPIO_PIN_13, 3, ADC_CHANNEL_NULL}, /* PE13 */
    {GPIOE, TIM1, NULL, GPIO_PIN_14, 4, ADC_CHANNEL_NULL}, /* PE14 */
    {GPIOE, NULL, NULL, GPIO_PIN_15, 0, ADC_CHANNEL_NULL}, /* PE15 */

    {GPIOF, NULL, NULL,  GPIO_PIN_0, 0, ADC_CHANNEL_NULL}, /* PF0 */
    {GPIOF, NULL, NULL,  GPIO_PIN_1, 0, ADC_CHANNEL_NULL}, /* PF1 */
    {GPIOF, NULL, NULL,  GPIO_PIN_2, 0, ADC_CHANNEL_NULL}, /* PF2 */
    {GPIOF, NULL, ADC3,  GPIO_PIN_3, 0, ADC_CHANNEL_9}, /* PF3 */
    {GPIOF, NULL, ADC3,  GPIO_PIN_4, 0, ADC_CHANNEL_14},/* PF4 */
    {GPIOF, NULL, ADC3,  GPIO_PIN_5, 0, ADC_CHANNEL_15},/* PF5 */
    {GPIOF, NULL, ADC3,  GPIO_PIN_6, 1, ADC_CHANNEL_4}, /* PF6 */
    {GPIOF, NULL, ADC3,  GPIO_PIN_7, 1, ADC_CHANNEL_5}, /* PF7 */
    {GPIOF, TIM13, ADC3,  GPIO_PIN_8, 1, ADC_CHANNEL_6}, /* PF8 */
    {GPIOF, TIM14, ADC3,  GPIO_PIN_9, 1, ADC_CHANNEL_7}, /* PF9 */
    {GPIOF, NULL, ADC3, GPIO_PIN_10, 0, ADC_CHANNEL_8}, /* PF10 */
    {GPIOF, NULL, NULL, GPIO_PIN_11, 0, ADC_CHANNEL_NULL}, /* PF11 */
    {GPIOF, NULL, NULL, GPIO_PIN_12, 0, ADC_CHANNEL_NULL}, /* PF12 */
    {GPIOF, NULL, NULL, GPIO_PIN_13, 0, ADC_CHANNEL_NULL}, /* PF13 */
    {GPIOF, NULL, NULL, GPIO_PIN_14, 0, ADC_CHANNEL_NULL}, /* PF14 */
    {GPIOF, NULL, NULL, GPIO_PIN_15, 0, ADC_CHANNEL_NULL}, /* PF15 */

    {GPIOG, NULL, NULL,  GPIO_PIN_0, 0, ADC_CHANNEL_NULL}, /* PG0 */
    {GPIOG, NULL, NULL,  GPIO_PIN_1, 0, ADC_CHANNEL_NULL}, /* PG1 */
    {GPIOG, NULL, NULL,  GPIO_PIN_2, 0, ADC_CHANNEL_NULL}, /* PG2 */
    {GPIOG, NULL, NULL,  GPIO_PIN_3, 0, ADC_CHANNEL_NULL}, /* PG3 */
    {GPIOG, NULL, NULL,  GPIO_PIN_4, 0, ADC_CHANNEL_NULL}, /* PG4 */
    {GPIOG, NULL, NULL,  GPIO_PIN_5, 0, ADC_CHANNEL_NULL}, /* PG5 */
    {GPIOG, NULL, NULL,  GPIO_PIN_6, 0, ADC_CHANNEL_NULL}, /* PG6 */
    {GPIOG, NULL, NULL,  GPIO_PIN_7, 0, ADC_CHANNEL_NULL}, /* PG7 */
    {GPIOG, NULL, NULL,  GPIO_PIN_8, 0, ADC_CHANNEL_NULL}, /* PG8 */
    {GPIOG, NULL, NULL,  GPIO_PIN_9, 0, ADC_CHANNEL_NULL}, /* PG9 */
    {GPIOG, NULL, NULL, GPIO_PIN_10, 0, ADC_CHANNEL_NULL}, /* PG10 */
    {GPIOG, NULL, NULL, GPIO_PIN_11, 0, ADC_CHANNEL_NULL}, /* PG11 */
    {GPIOG, NULL, NULL, GPIO_PIN_12, 0, ADC_CHANNEL_NULL}, /* PG12 */
    {GPIOG, NULL, NULL, GPIO_PIN_13, 0, ADC_CHANNEL_NULL}, /* PG13 */
    {GPIOG, NULL, NULL, GPIO_PIN_14, 0, ADC_CHANNEL_NULL}, /* PG14 */
    {GPIOG, NULL, NULL, GPIO_PIN_15, 0, ADC_CHANNEL_NULL}, /* PG15 */

    {GPIOH, NULL, NULL,  GPIO_PIN_0, 0, ADC_CHANNEL_NULL}, /* PH0 */
    {GPIOH, NULL, NULL,  GPIO_PIN_1, 0, ADC_CHANNEL_NULL}, /* PH1 */
    {GPIOH, NULL, NULL,  GPIO_PIN_2, 0, ADC_CHANNEL_NULL}, /* PH2 */
    {GPIOH, NULL, NULL,  GPIO_PIN_3, 0, ADC_CHANNEL_NULL}, /* PH3 */
    {GPIOH, NULL, NULL,  GPIO_PIN_4, 0, ADC_CHANNEL_NULL}, /* PH4 */
    {GPIOH, NULL, NULL,  GPIO_PIN_5, 0, ADC_CHANNEL_NULL}, /* PH5 */
    {GPIOH, NULL, NULL,  GPIO_PIN_6, 0, ADC_CHANNEL_NULL}, /* PH6 */
    {GPIOH, NULL, NULL,  GPIO_PIN_7, 0, ADC_CHANNEL_NULL}, /* PH7 */
    {GPIOH, NULL, NULL,  GPIO_PIN_8, 0, ADC_CHANNEL_NULL}, /* PH8 */
    {GPIOH, NULL, NULL,  GPIO_PIN_9, 0, ADC_CHANNEL_NULL}, /* PH9 */
    {GPIOH, NULL, NULL, GPIO_PIN_10, 0, ADC_CHANNEL_NULL}, /* PH10 */
    {GPIOH, NULL, NULL, GPIO_PIN_11, 0, ADC_CHANNEL_NULL}, /* PH11 */
    {GPIOH, NULL, NULL, GPIO_PIN_12, 0, ADC_CHANNEL_NULL}, /* PH12 */
    {GPIOH, NULL, NULL, GPIO_PIN_13, 0, ADC_CHANNEL_NULL}, /* PH13 */
    {GPIOH, NULL, NULL, GPIO_PIN_14, 0, ADC_CHANNEL_NULL}, /* PH14 */
    {GPIOH, NULL, NULL, GPIO_PIN_15, 0, ADC_CHANNEL_NULL}, /* PH15 */

    {GPIOI, NULL, NULL,  GPIO_PIN_0, 0, ADC_CHANNEL_NULL}, /* PI0 */
    {GPIOI, NULL, NULL,  GPIO_PIN_1, 0, ADC_CHANNEL_NULL}, /* PI1 */
    {GPIOI, NULL, NULL,  GPIO_PIN_2, 0, ADC_CHANNEL_NULL}, /* PI2 */
    {GPIOI, NULL, NULL,  GPIO_PIN_3, 0, ADC_CHANNEL_NULL}, /* PI3 */
    {GPIOI, NULL, NULL,  GPIO_PIN_4, 0, ADC_CHANNEL_NULL}, /* PI4 */
    {GPIOI, NULL, NULL,  GPIO_PIN_5, 0, ADC_CHANNEL_NULL}, /* PI5 */
    {GPIOI, NULL, NULL,  GPIO_PIN_6, 0, ADC_CHANNEL_NULL}, /* PI6 */
    {GPIOI, NULL, NULL,  GPIO_PIN_7, 0, ADC_CHANNEL_NULL}, /* PI7 */
    {GPIOI, NULL, NULL,  GPIO_PIN_8, 0, ADC_CHANNEL_NULL}, /* PI8 */
    {GPIOI, NULL, NULL,  GPIO_PIN_9, 0, ADC_CHANNEL_NULL}, /* PI9 */
    {GPIOI, NULL, NULL, GPIO_PIN_10, 0, ADC_CHANNEL_NULL}, /* PI10 */
    {GPIOI, NULL, NULL, GPIO_PIN_11, 0, ADC_CHANNEL_NULL}, /* PI11 */
    {GPIOI, NULL, NULL, GPIO_PIN_12, 0, ADC_CHANNEL_NULL}, /* PI12 */
    {GPIOI, NULL, NULL, GPIO_PIN_13, 0, ADC_CHANNEL_NULL}, /* PI13 */
    {GPIOI, NULL, NULL, GPIO_PIN_14, 0, ADC_CHANNEL_NULL}, /* PI14 */
    {GPIOI, NULL, NULL, GPIO_PIN_15, 0, ADC_CHANNEL_NULL}, /* PI15 */

    {GPIOJ, NULL, NULL,  GPIO_PIN_0, 0, ADC_CHANNEL_NULL}, /* PJ0 */
    {GPIOJ, NULL, NULL,  GPIO_PIN_1, 0, ADC_CHANNEL_NULL}, /* PJ1 */
    {GPIOJ, NULL, NULL,  GPIO_PIN_2, 0, ADC_CHANNEL_NULL}, /* PJ2 */
    {GPIOJ, NULL, NULL,  GPIO_PIN_3, 0, ADC_CHANNEL_NULL}, /* PJ3 */
    {GPIOJ, NULL, NULL,  GPIO_PIN_4, 0, ADC_CHANNEL_NULL}, /* PJ4 */
    {GPIOJ, NULL, NULL,  GPIO_PIN_5, 0, ADC_CHANNEL_NULL}, /* PJ5 */
    {GPIOJ, NULL, NULL,  GPIO_PIN_6, 0, ADC_CHANNEL_NULL}, /* PJ6 */
    {GPIOJ, NULL, NULL,  GPIO_PIN_7, 0, ADC_CHANNEL_NULL}, /* PJ7 */
    {GPIOJ, NULL, NULL,  GPIO_PIN_8, 0, ADC_CHANNEL_NULL}, /* PJ8 */
    {GPIOJ, NULL, NULL,  GPIO_PIN_9, 0, ADC_CHANNEL_NULL}, /* PJ9 */
    {GPIOJ, NULL, NULL, GPIO_PIN_10, 0, ADC_CHANNEL_NULL}, /* PJ10 */
    {GPIOJ, NULL, NULL, GPIO_PIN_11, 0, ADC_CHANNEL_NULL}, /* PJ11 */
    {GPIOJ, NULL, NULL, GPIO_PIN_12, 0, ADC_CHANNEL_NULL}, /* PJ12 */
    {GPIOJ, NULL, NULL, GPIO_PIN_13, 0, ADC_CHANNEL_NULL}, /* PJ13 */
    {GPIOJ, NULL, NULL, GPIO_PIN_14, 0, ADC_CHANNEL_NULL}, /* PJ14 */
    {GPIOJ, NULL, NULL, GPIO_PIN_15, 0, ADC_CHANNEL_NULL}, /* PJ15 */

    {GPIOK, NULL, NULL,  GPIO_PIN_0, 0, ADC_CHANNEL_NULL}, /* PK0 */
    {GPIOK, NULL, NULL,  GPIO_PIN_1, 0, ADC_CHANNEL_NULL}, /* PK1 */
    {GPIOK, NULL, NULL,  GPIO_PIN_2, 0, ADC_CHANNEL_NULL}, /* PK2 */
    {GPIOK, NULL, NULL,  GPIO_PIN_3, 0, ADC_CHANNEL_NULL}, /* PK3 */
    {GPIOK, NULL, NULL,  GPIO_PIN_4, 0, ADC_CHANNEL_NULL}, /* PK4 */
    {GPIOK, NULL, NULL,  GPIO_PIN_5, 0, ADC_CHANNEL_NULL}, /* PK5 */
    {GPIOK, NULL, NULL,  GPIO_PIN_6, 0, ADC_CHANNEL_NULL}, /* PK6 */
    {GPIOK, NULL, NULL,  GPIO_PIN_7, 0, ADC_CHANNEL_NULL}, /* PK7 */
    {GPIOK, NULL, NULL,  GPIO_PIN_8, 0, ADC_CHANNEL_NULL}, /* PK8 */
    {GPIOK, NULL, NULL,  GPIO_PIN_9, 0, ADC_CHANNEL_NULL}, /* PK9 */
    {GPIOK, NULL, NULL, GPIO_PIN_10, 0, ADC_CHANNEL_NULL}, /* PK10 */
    {GPIOK, NULL, NULL, GPIO_PIN_11, 0, ADC_CHANNEL_NULL}, /* PK11 */
    {GPIOK, NULL, NULL, GPIO_PIN_12, 0, ADC_CHANNEL_NULL}, /* PK12 */
    {GPIOK, NULL, NULL, GPIO_PIN_13, 0, ADC_CHANNEL_NULL}, /* PK13 */
    {GPIOK, NULL, NULL, GPIO_PIN_14, 0, ADC_CHANNEL_NULL}, /* PK14 */
    {GPIOK, NULL, NULL, GPIO_PIN_15, 0, ADC_CHANNEL_NULL}, /* PK15 */
};

/**
  * @brief  GPIO初始化
  * @param  GPIOx: GPIO地址
  * @param  GPIO_PIN_x: GPIO对应位
  * @param  GPIO_Mode_x: GPIO模式
  * @param  GPIO_Speed_x: GPIO速度
  * @retval 无
  */
void GPIOx_Init(GPIO_TypeDef* GPIOx, uint16_t GPIO_PIN_x, pinMode_TypeDef pinMode_x, uint32_t GPIO_Speed_x)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    uint32_t GPIO_Mode_x;
    uint32_t GPIO_PuPd_x;
    if(GPIOx == GPIOA) __HAL_RCC_GPIOA_CLK_ENABLE();
    else if(GPIOx == GPIOB)__HAL_RCC_GPIOB_CLK_ENABLE();
    else if(GPIOx == GPIOC)__HAL_RCC_GPIOC_CLK_ENABLE();
    else if(GPIOx == GPIOD)__HAL_RCC_GPIOD_CLK_ENABLE();
    else if(GPIOx == GPIOE)__HAL_RCC_GPIOE_CLK_ENABLE();
    else if(GPIOx == GPIOF)__HAL_RCC_GPIOF_CLK_ENABLE();
    else if(GPIOx == GPIOG)__HAL_RCC_GPIOG_CLK_ENABLE();
    else if(GPIOx == GPIOH)__HAL_RCC_GPIOH_CLK_ENABLE();
    else if(GPIOx == GPIOI)__HAL_RCC_GPIOI_CLK_ENABLE();
    else if(GPIOx == GPIOJ)__HAL_RCC_GPIOJ_CLK_ENABLE();
    else if(GPIOx == GPIOK)__HAL_RCC_GPIOK_CLK_ENABLE();
    else return;
    if(pinMode_x == INPUT)
    {
        GPIO_Mode_x  = GPIO_MODE_INPUT;
        GPIO_PuPd_x  = GPIO_NOPULL;
    }
    else if(pinMode_x == INPUT_PULLUP)
    {
        GPIO_Mode_x  = GPIO_MODE_INPUT;
        GPIO_PuPd_x  = GPIO_PULLUP;
    }
    else if(pinMode_x == INPUT_PULLDOWN)
    {
        GPIO_Mode_x  = GPIO_MODE_INPUT;
        GPIO_PuPd_x  = GPIO_PULLDOWN;
    }
    else if(pinMode_x == INPUT_ANALOG)
    {
        GPIO_Mode_x  = GPIO_MODE_ANALOG;
        GPIO_PuPd_x  = GPIO_NOPULL;
    }
    else if(pinMode_x == OUTPUT)
    {
        GPIO_Mode_x  = GPIO_MODE_OUTPUT_PP;
        GPIO_PuPd_x  = GPIO_NOPULL;
    }
    else if(pinMode_x == OUTPUT_OPEN_DRAIN)
    {
        GPIO_Mode_x  = GPIO_MODE_OUTPUT_OD;
        GPIO_PuPd_x  = GPIO_NOPULL;
    }
    else if(pinMode_x == OUTPUT_AF)
    {
        GPIO_Mode_x  = GPIO_MODE_AF_PP;
        GPIO_PuPd_x  = GPIO_NOPULL;
    }
    else
    {
        return;
    }
    GPIO_InitStructure.Pin = GPIO_PIN_x;
    GPIO_InitStructure.Mode = GPIO_Mode_x;
    GPIO_InitStructure.Speed = GPIO_Speed_x;
    GPIO_InitStructure.Pull = GPIO_PuPd_x;
    HAL_GPIO_Init(GPIOx,&GPIO_InitStructure);

}



/**
  * @brief  获取当前引脚对应的GPIOx编号
  * @param  Pin: 引脚编号
  * @retval 无
  */
uint8_t GPIO_GetPortNum(uint8_t Pin)
{
    if(PIN_MAP[Pin].GPIOx == GPIOA)return 0;
    else if(PIN_MAP[Pin].GPIOx == GPIOB)return 1;
    else if(PIN_MAP[Pin].GPIOx == GPIOC)return 2;
    else if(PIN_MAP[Pin].GPIOx == GPIOD)return 3;
    else if(PIN_MAP[Pin].GPIOx == GPIOE)return 4;
    else if(PIN_MAP[Pin].GPIOx == GPIOF)return 5;
    else if(PIN_MAP[Pin].GPIOx == GPIOG)return 6;
    else if(PIN_MAP[Pin].GPIOx == GPIOH)return 7;
    else if(PIN_MAP[Pin].GPIOx == GPIOI)return 8;
    else if(PIN_MAP[Pin].GPIOx == GPIOJ)return 9;
    else if(PIN_MAP[Pin].GPIOx == GPIOK)return 10;
    else return 0xFF;
}

/**
  * @brief  获取当前引脚对应的 PinSource
  * @param  GPIO_PIN_x: GPIO对应位
  * @retval 无
  */
uint8_t GPIO_GetPinSource(uint16_t GPIO_PIN_x)
{
    uint16_t PinSource = 0;
    while(GPIO_PIN_x > 1)
    {
        GPIO_PIN_x >>= 1;
        PinSource++;
    }
    return PinSource;
}

/**
  * @brief  获取当前引脚对应的编号
  * @param  Pin: 引脚编号
  * @retval 无
  */
uint8_t GPIO_GetPinNum(uint8_t Pin)
{
    return GPIO_GetPinSource(PIN_MAP[Pin].GPIO_Pin_x);
}
