//
// Created by Selected on 2022/3/15.
//
#include "common.h"
#include "Ticker.h"


void timer_callback()
{
    HAL_GPIO_TogglePin(LED_B_GPIO_Port,LED_B_Pin);
}

Ticker timer(timer_callback, 100, 0, MICROS_MICROS);

void initial_do()
{
    timer.start();
}

void loop_do()
{
    timer.update();
}


